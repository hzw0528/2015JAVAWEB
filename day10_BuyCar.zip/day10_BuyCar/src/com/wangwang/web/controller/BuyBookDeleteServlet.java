package com.wangwang.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wangwang.domain.BookCar;
import com.wangwang.exception.BookCarNotFoundException;
import com.wangwang.service.BookService;

/**
 * Servlet implementation class BuyBookDeleteServlet
 */
public class BuyBookDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// ����Ҫɾ����bookid
		String bookid = request.getParameter("bookid");
		// ��ù��ﳵ����
		BookCar bookCar = (BookCar) request.getSession()
				.getAttribute("bookcar");
		// ɾ����ҵ����service����
		BookService bookService = new BookService();
		try {
			bookService.deleteBuyCarByBookId(bookid, bookCar);
			request.getRequestDispatcher("/WEB-INF/pages/bookcarlist.jsp")
					.forward(request, response);
		} catch (BookCarNotFoundException e) {
			// TODO Auto-generated catch block
			request.setAttribute("message", e.getMessage());
			request.getRequestDispatcher("/WEB-INF/pages/message.jsp").forward(
					request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
