package com.wangwang.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wangwang.domain.BookCar;
import com.wangwang.service.BookService;

/**
 * Servlet implementation class BuyBookServlet
 */
public class BuyBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// ���Ҫ������鼮��ID
		String bookid = request.getParameter("bookid");
		// ����û��Ĺ��ﳵ
		BookCar bookCar = (BookCar) request.getSession()
				.getAttribute("bookcar");
		if (bookCar == null) {
			// ������ﳵ�ڱ��λỰΪ�յĻ����������µĻỰ���ﳵ
			bookCar = new BookCar();
			request.getSession().setAttribute("bookcar", bookCar);
		}
		// ҵ��������service�㴦��
		BookService bookService = new BookService();
		bookService.buyBook(bookid, bookCar);
		// ת��������ʾ���ﳵ��ҳ����
		request.getRequestDispatcher("/WEB-INF/pages/bookcarlist.jsp").forward(
				request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
