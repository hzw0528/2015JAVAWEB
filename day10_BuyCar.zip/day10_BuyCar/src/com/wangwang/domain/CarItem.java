package com.wangwang.domain;

/**
 * ���ﳵ��
 * 
 * @author wangwang
 * 
 */
public class CarItem {

	private Book book;
	/**
	 * ÿһ����������ܼ�
	 */
	private double price;

	/**
	 * ����
	 */
	private int quantity;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public double getPrice() {
		return book.getPrice() * this.quantity;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public CarItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarItem(Book book, double price) {
		super();
		this.book = book;
		this.price = price;
	}

}
