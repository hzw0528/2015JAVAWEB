package com.wangwang.dao;

import java.util.Map;

import com.wangwang.database.MyDb;
import com.wangwang.domain.Book;

public class BookDao {
	/**
	 * ������е��鼮
	 * @return
	 */
	public Map<String, Book> getAll() {
		return MyDb.getAll();
	}

	/**
	 * ����ID������
	 * @param id
	 * @return
	 */
	public Book find(String id) {
		return MyDb.getAll().get(id);
	}
}
